#!/bin/bash
java -cp bin:lib/jsc.jar main.Train $1
