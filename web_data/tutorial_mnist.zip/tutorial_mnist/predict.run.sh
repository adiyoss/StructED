#!/bin/bash
java -cp bin:lib/jsc.jar main.Test $1
