package Data.Entities;

public class VowelExample extends Example2D{

    private String label_2;

    //getters and setters
    public String getLabel_2() {
        return label_2;
    }

    public void setLabel_2(String label_2) {
        this.label_2 = label_2;
    }
}
