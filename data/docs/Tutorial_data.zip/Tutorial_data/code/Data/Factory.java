/*
 * StructED - Machine Learning, Structured Prediction Package written in Java.
 * Copyright (C) 2014 Yossi Adi, E-Mail: yossiadidrum@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Data;

import BL.*;
import BL.Algorithms.*;
import BL.Kernels.Poly2Kernel;
import BL.Kernels.RBF2Kernel;
import BL.Kernels.RBF3Kernel;
import BL.Prediction.*;
import BL.TaskLoss.*;
import Data.Entities.*;
import Data.FeatureFunctions.*;
import DataAccess.*;

import java.util.ArrayList;

public class Factory {
	
    //==========PLACE YOUR CODE HERE=========//
    //=======================================//

	//==============DATA ACCESS==============//
	//type is not supported
	//StandardReader getter object
	public static Reader getReader(int type){
        switch(type){
            case 0:
		        return new StandardReader();
            case 1:
                return new RankReader();
            case 2:
                return new VowelDurationReader();
            default:
                return new StandardReader();
        }
	}
	//type is not supported
	//Writer getter object
	public static Writer getWriter(int type){
        switch (type){
            case 0:
		        return new StandardWriter();
            case 1:
                return new RankWriter();
            default:
                return new StandardWriter();
        }
	}
	
	//type is not supported
	//Config File getter object
	public static ConfigFileGetter getConfigGetter(int type){
		return new ConfigFileGetter();
	}
	//=======================================//
	//===============DATA TYPES==============//
	//type is not supported
	//data vector getter object
	public static Example getExample(int type){
        switch(type){
            case 0:
                return new ExampleStandard();

            case 1:
                return new Example2D();

            case 2:
                return new VowelExample();

            default:
                return new ExampleStandard();
        }
	}

    public static InstancesContainer getInstanceContainer(int type){
        switch(type) {
            case 0:
                return new InstancesContainer();
            case 1:
                return new LazyInstancesContainer();
            default:
                return new InstancesContainer();
        }
    }
}
