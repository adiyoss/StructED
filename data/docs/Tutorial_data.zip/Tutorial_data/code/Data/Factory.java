package Data;

import BL.*;
import BL.Algorithms.*;
import BL.Kernels.Poly2Kernel;
import BL.Kernels.RBF2Kernel;
import BL.Kernels.RBF3Kernel;
import BL.Prediction.*;
import BL.TaskLoss.*;
import Data.Entities.*;
import Data.FeatureFunctions.*;
import DataAccess.*;

import java.util.ArrayList;

public class Factory {
	
	//==============DATA ACCESS==============//
	//type is not supported
	//StandardReader getter object
	public static Reader getReader(int type){
        switch(type){
            case 0:
		        return new StandardReader();
            case 1:
                return new RankReader();
            case 2:
                return new VowelDurationReader();
            default:
                return new StandardReader();
        }
	}
	//type is not supported
	//Writer getter object
	public static Writer getWriter(int type){
        switch (type){
            case 0:
		        return new StandardWriter();
            case 1:
                return new RankWriter();
            default:
                return new StandardWriter();
        }
	}
	
	//type is not supported
	//Config File getter object
	public static ConfigFileGetter getConfigGetter(int type){
		return new ConfigFileGetter();
	}
	//=======================================//
	//===============DATA TYPES==============//
	//type is not supported
	//data vector getter object
	public static Example getExample(int type){
        switch(type){
            case 0:
                return new ExampleStandard();

            case 1:
                return new Example2D();

            case 2:
                return new VowelExample();

            default:
                return new ExampleStandard();
        }
	}

    public static InstancesContainer getInstanceContainer(int type){
        switch(type) {
            case 0:
                return new InstancesContainer();
            case 1:
                return new LazyInstancesContainer();
            default:
                return new InstancesContainer();
        }
    }

    //=========================//
    //===PLACE THE CODE HERE===//
    //=========================//
}
