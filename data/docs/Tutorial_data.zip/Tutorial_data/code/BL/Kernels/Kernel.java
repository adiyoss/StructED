package BL.Kernels;

import Data.Entities.Vector;

public interface Kernel {
    public Vector convertVector(Vector vector, int vectorSize);

}